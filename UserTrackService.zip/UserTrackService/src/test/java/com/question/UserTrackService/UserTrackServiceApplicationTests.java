package com.question.UserTrackService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserTrackServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
